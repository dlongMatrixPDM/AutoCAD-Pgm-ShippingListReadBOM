Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.


' TODO: Review the values of the assembly attributes


<Assembly: AssemblyTitle("Shipping List Generator")> 
<Assembly: AssemblyDescription("Produce list of Items to be shipped.")> 
<Assembly: AssemblyCompany("Matrix PDM Engineering")> 
<Assembly: AssemblyProduct("Create Shipping List and Compare to Previous version-Win10")> 
<Assembly: AssemblyCopyright("Copyright � Matrix  2010")> 
<Assembly: AssemblyTrademark("")>
<Assembly: AssemblyCulture("")>

' Version information for an assembly consists of the following four values:

'	Major version
'	Minor Version
'	Build Number
'	Revision

' You can specify all the values or you can default the Build and Revision Numbers
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.0.1")> 


