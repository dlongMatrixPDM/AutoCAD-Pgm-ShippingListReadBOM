'Module UpgradeSupport
'Friend VBAGlobal_definst As VBA.Global = New VBA.Global
'Friend AutoCADAcadApplication_definst As New Autodesk.AutoCAD.Interop.AcadApplication
'End Module