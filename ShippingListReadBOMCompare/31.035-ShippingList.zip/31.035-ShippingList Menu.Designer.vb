﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ShippingList_Menu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ShippingList_Menu))
        Me.File3 = New Microsoft.VisualBasic.Compatibility.VB6.FileListBox()
        Me.Dir2 = New Microsoft.VisualBasic.Compatibility.VB6.DirListBox()
        Me.Drive2 = New Microsoft.VisualBasic.Compatibility.VB6.DriveListBox()
        Me.File1 = New Microsoft.VisualBasic.Compatibility.VB6.FileListBox()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.BtnStart2 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.BtnNewDirPathbox = New System.Windows.Forms.Button()
        Me.ShipListBox = New System.Windows.Forms.ListBox()
        Me.File2 = New Microsoft.VisualBasic.Compatibility.VB6.FileListBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.btnNewDir = New System.Windows.Forms.Button()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.DwgList = New System.Windows.Forms.ListBox()
        Me.SelectList = New System.Windows.Forms.ListBox()
        Me.BtnAdd = New System.Windows.Forms.Button()
        Me.BtnAddAll = New System.Windows.Forms.Button()
        Me.BtnRemove = New System.Windows.Forms.Button()
        Me.BtnClear = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Dir1 = New Microsoft.VisualBasic.Compatibility.VB6.DirListBox()
        Me.Drive1 = New Microsoft.VisualBasic.Compatibility.VB6.DriveListBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.RadioButton3 = New System.Windows.Forms.RadioButton()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.ViewFilesButton = New System.Windows.Forms.Button()
        Me.HelpButton_Renamed = New System.Windows.Forms.Button()
        Me.CancelButton_Renamed = New System.Windows.Forms.Button()
        Me.MatrixLogo = New System.Windows.Forms.PictureBox()
        Me.ChkBoxAutoCAD3D = New System.Windows.Forms.CheckBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.BtnGetMWInfo = New System.Windows.Forms.Button()
        Me.PathBox = New System.Windows.Forms.TextBox()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.PathBox2 = New System.Windows.Forms.TextBox()
        Me.TxtBoxCntDown = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.BtnSpeedTest = New System.Windows.Forms.Button()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.MatrixLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox6.SuspendLayout()
        Me.SuspendLayout()
        '
        'File3
        '
        Me.File3.BackColor = System.Drawing.SystemColors.Window
        Me.File3.Cursor = System.Windows.Forms.Cursors.Default
        Me.File3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.File3.ForeColor = System.Drawing.SystemColors.WindowText
        Me.File3.FormattingEnabled = True
        Me.File3.Location = New System.Drawing.Point(356, 60)
        Me.File3.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.File3.Name = "File3"
        Me.File3.Pattern = "*.dwg"
        Me.File3.Size = New System.Drawing.Size(92, 4)
        Me.File3.TabIndex = 52
        Me.File3.Visible = False
        '
        'Dir2
        '
        Me.Dir2.BackColor = System.Drawing.SystemColors.Window
        Me.Dir2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Dir2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dir2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Dir2.FormattingEnabled = True
        Me.Dir2.IntegralHeight = False
        Me.Dir2.Location = New System.Drawing.Point(829, 409)
        Me.Dir2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Dir2.Name = "Dir2"
        Me.Dir2.Size = New System.Drawing.Size(67, 11)
        Me.Dir2.TabIndex = 51
        Me.Dir2.Visible = False
        '
        'Drive2
        '
        Me.Drive2.BackColor = System.Drawing.SystemColors.Window
        Me.Drive2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Drive2.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Drive2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Drive2.FormattingEnabled = True
        Me.Drive2.Location = New System.Drawing.Point(829, 428)
        Me.Drive2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Drive2.Name = "Drive2"
        Me.Drive2.Size = New System.Drawing.Size(61, 30)
        Me.Drive2.TabIndex = 50
        Me.Drive2.Visible = False
        '
        'File1
        '
        Me.File1.BackColor = System.Drawing.SystemColors.Window
        Me.File1.Cursor = System.Windows.Forms.Cursors.Default
        Me.File1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.File1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.File1.FormattingEnabled = True
        Me.File1.Location = New System.Drawing.Point(560, 12)
        Me.File1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.File1.Name = "File1"
        Me.File1.Pattern = "*.dwg"
        Me.File1.Size = New System.Drawing.Size(47, 4)
        Me.File1.TabIndex = 49
        Me.File1.Visible = False
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(16, 537)
        Me.ProgressBar1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(876, 27)
        Me.ProgressBar1.TabIndex = 48
        '
        'BtnStart2
        '
        Me.BtnStart2.BackColor = System.Drawing.SystemColors.Control
        Me.BtnStart2.Cursor = System.Windows.Forms.Cursors.Default
        Me.BtnStart2.Enabled = False
        Me.BtnStart2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnStart2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnStart2.Location = New System.Drawing.Point(813, 314)
        Me.BtnStart2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BtnStart2.Name = "BtnStart2"
        Me.BtnStart2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnStart2.Size = New System.Drawing.Size(85, 39)
        Me.BtnStart2.TabIndex = 47
        Me.BtnStart2.Text = "Start"
        Me.BtnStart2.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(369, 36)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(540, 36)
        Me.Label1.TabIndex = 46
        Me.Label1.Text = "Shipping List 2024"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(19, 512)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label2.Size = New System.Drawing.Size(891, 20)
        Me.Label2.TabIndex = 45
        Me.Label2.Text = "Progress........"
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.BtnNewDirPathbox)
        Me.GroupBox5.Controls.Add(Me.ShipListBox)
        Me.GroupBox5.Controls.Add(Me.File2)
        Me.GroupBox5.Controls.Add(Me.CheckBox1)
        Me.GroupBox5.Controls.Add(Me.File3)
        Me.GroupBox5.Location = New System.Drawing.Point(21, 428)
        Me.GroupBox5.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox5.Size = New System.Drawing.Size(804, 80)
        Me.GroupBox5.TabIndex = 44
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Comparison"
        '
        'BtnNewDirPathbox
        '
        Me.BtnNewDirPathbox.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnNewDirPathbox.Location = New System.Drawing.Point(356, 23)
        Me.BtnNewDirPathbox.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BtnNewDirPathbox.Name = "BtnNewDirPathbox"
        Me.BtnNewDirPathbox.Size = New System.Drawing.Size(92, 32)
        Me.BtnNewDirPathbox.TabIndex = 57
        Me.BtnNewDirPathbox.Text = "New Directory"
        Me.BtnNewDirPathbox.UseVisualStyleBackColor = True
        '
        'ShipListBox
        '
        Me.ShipListBox.BackColor = System.Drawing.SystemColors.Window
        Me.ShipListBox.Cursor = System.Windows.Forms.Cursors.Default
        Me.ShipListBox.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ShipListBox.ForeColor = System.Drawing.SystemColors.WindowText
        Me.ShipListBox.ItemHeight = 17
        Me.ShipListBox.Location = New System.Drawing.Point(456, 6)
        Me.ShipListBox.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.ShipListBox.Name = "ShipListBox"
        Me.ShipListBox.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ShipListBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.ShipListBox.Size = New System.Drawing.Size(335, 72)
        Me.ShipListBox.TabIndex = 56
        '
        'File2
        '
        Me.File2.BackColor = System.Drawing.SystemColors.Window
        Me.File2.Cursor = System.Windows.Forms.Cursors.Default
        Me.File2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.File2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.File2.FormattingEnabled = True
        Me.File2.Location = New System.Drawing.Point(184, 23)
        Me.File2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.File2.Name = "File2"
        Me.File2.Pattern = "*.XLS"
        Me.File2.Size = New System.Drawing.Size(164, 4)
        Me.File2.TabIndex = 18
        Me.File2.Visible = False
        '
        'CheckBox1
        '
        Me.CheckBox1.BackColor = System.Drawing.SystemColors.Control
        Me.CheckBox1.Cursor = System.Windows.Forms.Cursors.Default
        Me.CheckBox1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CheckBox1.Location = New System.Drawing.Point(7, 23)
        Me.CheckBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CheckBox1.Size = New System.Drawing.Size(169, 50)
        Me.CheckBox1.TabIndex = 0
        Me.CheckBox1.Text = "Compare To Existing Shipping List"
        Me.CheckBox1.UseVisualStyleBackColor = False
        '
        'btnNewDir
        '
        Me.btnNewDir.BackColor = System.Drawing.SystemColors.Control
        Me.btnNewDir.Cursor = System.Windows.Forms.Cursors.Default
        Me.btnNewDir.Enabled = False
        Me.btnNewDir.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNewDir.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btnNewDir.Location = New System.Drawing.Point(829, 474)
        Me.btnNewDir.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btnNewDir.Name = "btnNewDir"
        Me.btnNewDir.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btnNewDir.Size = New System.Drawing.Size(63, 20)
        Me.btnNewDir.TabIndex = 31
        Me.btnNewDir.Text = "New Directory"
        Me.btnNewDir.UseVisualStyleBackColor = False
        Me.btnNewDir.Visible = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.DwgList)
        Me.GroupBox4.Controls.Add(Me.SelectList)
        Me.GroupBox4.Controls.Add(Me.BtnAdd)
        Me.GroupBox4.Controls.Add(Me.BtnAddAll)
        Me.GroupBox4.Controls.Add(Me.BtnRemove)
        Me.GroupBox4.Controls.Add(Me.BtnClear)
        Me.GroupBox4.Location = New System.Drawing.Point(9, 175)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox4.Size = New System.Drawing.Size(797, 215)
        Me.GroupBox4.TabIndex = 43
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Drawings Found in Directory above.                        Selected Drawings"
        '
        'DwgList
        '
        Me.DwgList.BackColor = System.Drawing.SystemColors.Window
        Me.DwgList.Cursor = System.Windows.Forms.Cursors.Default
        Me.DwgList.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DwgList.ForeColor = System.Drawing.SystemColors.WindowText
        Me.DwgList.ItemHeight = 17
        Me.DwgList.Location = New System.Drawing.Point(12, 31)
        Me.DwgList.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.DwgList.Name = "DwgList"
        Me.DwgList.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.DwgList.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.DwgList.Size = New System.Drawing.Size(332, 140)
        Me.DwgList.TabIndex = 16
        '
        'SelectList
        '
        Me.SelectList.BackColor = System.Drawing.SystemColors.Window
        Me.SelectList.Cursor = System.Windows.Forms.Cursors.Default
        Me.SelectList.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SelectList.ForeColor = System.Drawing.SystemColors.WindowText
        Me.SelectList.ItemHeight = 17
        Me.SelectList.Location = New System.Drawing.Point(451, 31)
        Me.SelectList.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.SelectList.Name = "SelectList"
        Me.SelectList.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SelectList.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.SelectList.Size = New System.Drawing.Size(335, 140)
        Me.SelectList.TabIndex = 15
        '
        'BtnAdd
        '
        Me.BtnAdd.BackColor = System.Drawing.SystemColors.Control
        Me.BtnAdd.Cursor = System.Windows.Forms.Cursors.Default
        Me.BtnAdd.Enabled = False
        Me.BtnAdd.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnAdd.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnAdd.Location = New System.Drawing.Point(353, 27)
        Me.BtnAdd.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BtnAdd.Name = "BtnAdd"
        Me.BtnAdd.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnAdd.Size = New System.Drawing.Size(89, 39)
        Me.BtnAdd.TabIndex = 8
        Me.BtnAdd.Text = "&Add ->"
        Me.BtnAdd.UseVisualStyleBackColor = False
        '
        'BtnAddAll
        '
        Me.BtnAddAll.BackColor = System.Drawing.SystemColors.Control
        Me.BtnAddAll.Cursor = System.Windows.Forms.Cursors.Default
        Me.BtnAddAll.Enabled = False
        Me.BtnAddAll.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnAddAll.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnAddAll.Location = New System.Drawing.Point(353, 74)
        Me.BtnAddAll.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BtnAddAll.Name = "BtnAddAll"
        Me.BtnAddAll.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnAddAll.Size = New System.Drawing.Size(89, 39)
        Me.BtnAddAll.TabIndex = 9
        Me.BtnAddAll.Text = "A&dd All ->"
        Me.BtnAddAll.UseVisualStyleBackColor = False
        '
        'BtnRemove
        '
        Me.BtnRemove.BackColor = System.Drawing.SystemColors.Control
        Me.BtnRemove.Cursor = System.Windows.Forms.Cursors.Default
        Me.BtnRemove.Enabled = False
        Me.BtnRemove.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnRemove.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnRemove.Location = New System.Drawing.Point(353, 121)
        Me.BtnRemove.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BtnRemove.Name = "BtnRemove"
        Me.BtnRemove.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnRemove.Size = New System.Drawing.Size(89, 39)
        Me.BtnRemove.TabIndex = 10
        Me.BtnRemove.Text = "<-Remove"
        Me.BtnRemove.UseVisualStyleBackColor = False
        '
        'BtnClear
        '
        Me.BtnClear.BackColor = System.Drawing.SystemColors.Control
        Me.BtnClear.Cursor = System.Windows.Forms.Cursors.Default
        Me.BtnClear.Enabled = False
        Me.BtnClear.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnClear.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnClear.Location = New System.Drawing.Point(353, 167)
        Me.BtnClear.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BtnClear.Name = "BtnClear"
        Me.BtnClear.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnClear.Size = New System.Drawing.Size(89, 39)
        Me.BtnClear.TabIndex = 11
        Me.BtnClear.Text = "&Clear"
        Me.BtnClear.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(814, 160)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label3.Size = New System.Drawing.Size(104, 25)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Revision No:"
        '
        'ComboBox1
        '
        Me.ComboBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(815, 189)
        Me.ComboBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(83, 25)
        Me.ComboBox1.TabIndex = 0
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Dir1)
        Me.GroupBox2.Controls.Add(Me.Drive1)
        Me.GroupBox2.Location = New System.Drawing.Point(451, 2)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox2.Size = New System.Drawing.Size(101, 20)
        Me.GroupBox2.TabIndex = 41
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Select Path"
        Me.GroupBox2.Visible = False
        '
        'Dir1
        '
        Me.Dir1.BackColor = System.Drawing.SystemColors.Window
        Me.Dir1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Dir1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Dir1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Dir1.FormattingEnabled = True
        Me.Dir1.IntegralHeight = False
        Me.Dir1.Location = New System.Drawing.Point(12, 62)
        Me.Dir1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Dir1.Name = "Dir1"
        Me.Dir1.Size = New System.Drawing.Size(453, 91)
        Me.Dir1.TabIndex = 7
        '
        'Drive1
        '
        Me.Drive1.BackColor = System.Drawing.SystemColors.Window
        Me.Drive1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Drive1.Font = New System.Drawing.Font("Arial", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Drive1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.Drive1.FormattingEnabled = True
        Me.Drive1.Location = New System.Drawing.Point(12, 23)
        Me.Drive1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Drive1.Name = "Drive1"
        Me.Drive1.Size = New System.Drawing.Size(93, 30)
        Me.Drive1.TabIndex = 6
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RadioButton1)
        Me.GroupBox1.Location = New System.Drawing.Point(756, 32)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox1.Size = New System.Drawing.Size(153, 23)
        Me.GroupBox1.TabIndex = 40
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Type of Shipping List"
        Me.GroupBox1.Visible = False
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Checked = True
        Me.RadioButton1.Location = New System.Drawing.Point(39, 18)
        Me.RadioButton1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(138, 20)
        Me.RadioButton1.TabIndex = 20
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Tank Shipping List"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'RadioButton3
        '
        Me.RadioButton3.AutoSize = True
        Me.RadioButton3.Location = New System.Drawing.Point(767, 4)
        Me.RadioButton3.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.Size = New System.Drawing.Size(138, 20)
        Me.RadioButton3.TabIndex = 22
        Me.RadioButton3.TabStop = True
        Me.RadioButton3.Text = "Intent Shipping List"
        Me.RadioButton3.UseVisualStyleBackColor = True
        Me.RadioButton3.Visible = False
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Location = New System.Drawing.Point(613, 11)
        Me.RadioButton2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(135, 20)
        Me.RadioButton2.TabIndex = 21
        Me.RadioButton2.TabStop = True
        Me.RadioButton2.Text = "Seal Shipping List"
        Me.RadioButton2.UseVisualStyleBackColor = True
        Me.RadioButton2.Visible = False
        '
        'ViewFilesButton
        '
        Me.ViewFilesButton.BackColor = System.Drawing.SystemColors.Control
        Me.ViewFilesButton.Cursor = System.Windows.Forms.Cursors.Default
        Me.ViewFilesButton.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ViewFilesButton.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ViewFilesButton.Location = New System.Drawing.Point(815, 222)
        Me.ViewFilesButton.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.ViewFilesButton.Name = "ViewFilesButton"
        Me.ViewFilesButton.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ViewFilesButton.Size = New System.Drawing.Size(85, 39)
        Me.ViewFilesButton.TabIndex = 39
        Me.ViewFilesButton.Text = "View Files"
        Me.ViewFilesButton.UseVisualStyleBackColor = False
        '
        'HelpButton_Renamed
        '
        Me.HelpButton_Renamed.BackColor = System.Drawing.SystemColors.Control
        Me.HelpButton_Renamed.Cursor = System.Windows.Forms.Cursors.Default
        Me.HelpButton_Renamed.Enabled = False
        Me.HelpButton_Renamed.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HelpButton_Renamed.ForeColor = System.Drawing.SystemColors.ControlText
        Me.HelpButton_Renamed.Location = New System.Drawing.Point(815, 267)
        Me.HelpButton_Renamed.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.HelpButton_Renamed.Name = "HelpButton_Renamed"
        Me.HelpButton_Renamed.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.HelpButton_Renamed.Size = New System.Drawing.Size(85, 39)
        Me.HelpButton_Renamed.TabIndex = 37
        Me.HelpButton_Renamed.Text = "Help"
        Me.HelpButton_Renamed.UseVisualStyleBackColor = False
        Me.HelpButton_Renamed.Visible = False
        '
        'CancelButton_Renamed
        '
        Me.CancelButton_Renamed.BackColor = System.Drawing.SystemColors.Control
        Me.CancelButton_Renamed.Cursor = System.Windows.Forms.Cursors.Default
        Me.CancelButton_Renamed.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CancelButton_Renamed.ForeColor = System.Drawing.SystemColors.ControlText
        Me.CancelButton_Renamed.Location = New System.Drawing.Point(811, 362)
        Me.CancelButton_Renamed.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.CancelButton_Renamed.Name = "CancelButton_Renamed"
        Me.CancelButton_Renamed.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.CancelButton_Renamed.Size = New System.Drawing.Size(85, 39)
        Me.CancelButton_Renamed.TabIndex = 38
        Me.CancelButton_Renamed.Text = "&Cancel"
        Me.CancelButton_Renamed.UseVisualStyleBackColor = False
        '
        'MatrixLogo
        '
        Me.MatrixLogo.BackgroundImage = CType(resources.GetObject("MatrixLogo.BackgroundImage"), System.Drawing.Image)
        Me.MatrixLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.MatrixLogo.Location = New System.Drawing.Point(16, 4)
        Me.MatrixLogo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.MatrixLogo.Name = "MatrixLogo"
        Me.MatrixLogo.Size = New System.Drawing.Size(345, 97)
        Me.MatrixLogo.TabIndex = 53
        Me.MatrixLogo.TabStop = False
        '
        'ChkBoxAutoCAD3D
        '
        Me.ChkBoxAutoCAD3D.AutoSize = True
        Me.ChkBoxAutoCAD3D.Location = New System.Drawing.Point(804, 54)
        Me.ChkBoxAutoCAD3D.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ChkBoxAutoCAD3D.Name = "ChkBoxAutoCAD3D"
        Me.ChkBoxAutoCAD3D.Size = New System.Drawing.Size(104, 20)
        Me.ChkBoxAutoCAD3D.TabIndex = 54
        Me.ChkBoxAutoCAD3D.Text = "AutoCAD 3D"
        Me.ChkBoxAutoCAD3D.UseVisualStyleBackColor = True
        Me.ChkBoxAutoCAD3D.Visible = False
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.BtnGetMWInfo)
        Me.GroupBox6.Controls.Add(Me.PathBox)
        Me.GroupBox6.Location = New System.Drawing.Point(9, 110)
        Me.GroupBox6.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Padding = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.GroupBox6.Size = New System.Drawing.Size(759, 58)
        Me.GroupBox6.TabIndex = 55
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Select Path"
        '
        'BtnGetMWInfo
        '
        Me.BtnGetMWInfo.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnGetMWInfo.Location = New System.Drawing.Point(699, 17)
        Me.BtnGetMWInfo.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BtnGetMWInfo.Name = "BtnGetMWInfo"
        Me.BtnGetMWInfo.Size = New System.Drawing.Size(51, 33)
        Me.BtnGetMWInfo.TabIndex = 10
        Me.BtnGetMWInfo.Text = "..."
        Me.BtnGetMWInfo.UseVisualStyleBackColor = True
        '
        'PathBox
        '
        Me.PathBox.Location = New System.Drawing.Point(12, 23)
        Me.PathBox.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.PathBox.Name = "PathBox"
        Me.PathBox.Size = New System.Drawing.Size(677, 22)
        Me.PathBox.TabIndex = 9
        Me.PathBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'PathBox2
        '
        Me.PathBox2.Location = New System.Drawing.Point(21, 398)
        Me.PathBox2.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.PathBox2.Name = "PathBox2"
        Me.PathBox2.Size = New System.Drawing.Size(785, 22)
        Me.PathBox2.TabIndex = 56
        Me.PathBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TxtBoxCntDown
        '
        Me.TxtBoxCntDown.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtBoxCntDown.Location = New System.Drawing.Point(818, 122)
        Me.TxtBoxCntDown.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.TxtBoxCntDown.Name = "TxtBoxCntDown"
        Me.TxtBoxCntDown.Size = New System.Drawing.Size(81, 34)
        Me.TxtBoxCntDown.TabIndex = 57
        Me.TxtBoxCntDown.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label4.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(738, 92)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label4.Size = New System.Drawing.Size(165, 26)
        Me.Label4.TabIndex = 58
        Me.Label4.Text = "No of Drawings."
        '
        'BtnSpeedTest
        '
        Me.BtnSpeedTest.BackColor = System.Drawing.SystemColors.Control
        Me.BtnSpeedTest.Cursor = System.Windows.Forms.Cursors.Default
        Me.BtnSpeedTest.Enabled = False
        Me.BtnSpeedTest.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSpeedTest.ForeColor = System.Drawing.SystemColors.ControlText
        Me.BtnSpeedTest.Location = New System.Drawing.Point(362, -3)
        Me.BtnSpeedTest.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.BtnSpeedTest.Name = "BtnSpeedTest"
        Me.BtnSpeedTest.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.BtnSpeedTest.Size = New System.Drawing.Size(94, 20)
        Me.BtnSpeedTest.TabIndex = 59
        Me.BtnSpeedTest.Text = "Speed Test"
        Me.BtnSpeedTest.UseVisualStyleBackColor = False
        Me.BtnSpeedTest.Visible = False
        '
        'ShippingList_Menu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(915, 574)
        Me.Controls.Add(Me.BtnSpeedTest)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TxtBoxCntDown)
        Me.Controls.Add(Me.btnNewDir)
        Me.Controls.Add(Me.PathBox2)
        Me.Controls.Add(Me.RadioButton2)
        Me.Controls.Add(Me.RadioButton3)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.ChkBoxAutoCAD3D)
        Me.Controls.Add(Me.MatrixLogo)
        Me.Controls.Add(Me.Dir2)
        Me.Controls.Add(Me.Drive2)
        Me.Controls.Add(Me.File1)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.BtnStart2)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.ViewFilesButton)
        Me.Controls.Add(Me.HelpButton_Renamed)
        Me.Controls.Add(Me.CancelButton_Renamed)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "ShippingList_Menu"
        Me.Text = "Menu--Shipping List 2024"
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.MatrixLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Public WithEvents File3 As Microsoft.VisualBasic.Compatibility.VB6.FileListBox
    Public WithEvents Dir2 As Microsoft.VisualBasic.Compatibility.VB6.DirListBox
    Public WithEvents Drive2 As Microsoft.VisualBasic.Compatibility.VB6.DriveListBox
    Public WithEvents File1 As Microsoft.VisualBasic.Compatibility.VB6.FileListBox
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Public WithEvents BtnStart2 As System.Windows.Forms.Button
    Public WithEvents Label1 As System.Windows.Forms.Label
    Public WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Public WithEvents btnNewDir As System.Windows.Forms.Button
    Public WithEvents File2 As Microsoft.VisualBasic.Compatibility.VB6.FileListBox
    Public WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Public WithEvents DwgList As System.Windows.Forms.ListBox
    Public WithEvents SelectList As System.Windows.Forms.ListBox
    Public WithEvents BtnAdd As System.Windows.Forms.Button
    Public WithEvents BtnAddAll As System.Windows.Forms.Button
    Public WithEvents BtnRemove As System.Windows.Forms.Button
    Public WithEvents BtnClear As System.Windows.Forms.Button
    Public WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Public WithEvents Dir1 As Microsoft.VisualBasic.Compatibility.VB6.DirListBox
    Public WithEvents Drive1 As Microsoft.VisualBasic.Compatibility.VB6.DriveListBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton3 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Public WithEvents ViewFilesButton As System.Windows.Forms.Button
    Public WithEvents HelpButton_Renamed As System.Windows.Forms.Button
    Public WithEvents CancelButton_Renamed As System.Windows.Forms.Button
    Friend WithEvents MatrixLogo As System.Windows.Forms.PictureBox
    Friend WithEvents ChkBoxAutoCAD3D As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents BtnGetMWInfo As System.Windows.Forms.Button
    Friend WithEvents PathBox As System.Windows.Forms.TextBox
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Public WithEvents ShipListBox As System.Windows.Forms.ListBox
    Friend WithEvents PathBox2 As System.Windows.Forms.TextBox
    Friend WithEvents BtnNewDirPathbox As System.Windows.Forms.Button
    Friend WithEvents TxtBoxCntDown As System.Windows.Forms.TextBox
    Public WithEvents Label4 As System.Windows.Forms.Label
    Public WithEvents BtnSpeedTest As System.Windows.Forms.Button
End Class
