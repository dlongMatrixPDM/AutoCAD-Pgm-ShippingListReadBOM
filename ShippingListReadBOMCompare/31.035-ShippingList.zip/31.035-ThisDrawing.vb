Option Strict On           'Option Strict Off
Option Explicit On
<System.Runtime.InteropServices.ProgId("ThisDrawing_NET.ThisDrawing")> Public Class ThisDrawing
End Class